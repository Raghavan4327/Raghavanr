import React from "react";

function Checkout({ cart }) {
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div>
      <h2 className="title2">✅ Checkout</h2>
      {cart.length === 0 ? (
        <p className="title2">No items in cart</p>
      ) : (
        <div>
          <ul>
            {cart.map((item, index) => (
              <li className="list" key={index}>
                {item.name} - ₹{item.price}
              </li>
            ))}
          </ul>
          <h3 className="total">Total: ₹{total}</h3>
          <button onClick={() => alert("Order placed successfully!")} className="button2">
            Place Order
          </button>
        </div>
      )}
    </div>
  );
}

export default Checkout;
