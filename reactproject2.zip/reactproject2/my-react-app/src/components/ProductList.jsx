import React from "react";
import "./ProductList.css";   
import tomato from "../assets/tomato.png";
import onion from "../assets/onion.png";
import carrot from "../assets/carrot.png";
import ginger from "../assets/ginger.png";
import pattato from "../assets/pattato.png";
import mushroom from "../assets/mushroom.png";
import brinjal from "../assets/brinjal.png";
import gralic from "../assets/gralic.png";
import chilli from "../assets/chilli.png";
import capsicum from "../assets/capsicum.png";
import bg from "../assets/bg.png"



const products = [
  { id: 1, name: "TOMATO", price: 60, image: tomato },
  { id: 2, name: "ONION", price: 140, image: onion },
  { id: 3, name: "CARROT", price: 30, image: carrot },
  { id: 4, name: "GINGER", price: 45, image: ginger },
  { id: 5, name: "POTATO", price: 65, image: pattato },
  { id: 6, name: "MUSHROOM", price: 135, image: mushroom },
  { id: 7, name:"BRINJAL", price: 40, image: brinjal},
  { id: 8, name:"GRALIC", price: 95, image: gralic},
  { id: 9, name:"CHILLI", price: 20, image: chilli},
  { id: 10, name:"CAPSICUM", price:35, image: capsicum}
];

function ProductList({ addToCart }) {
  return (
    <div>
      <h1 className="title">Ramesh Vegtable Shop</h1>
      <div className="product-grid">
        {products.map((item) => (
          <div key={item.id} className="product-card">
            <img src={item.image} alt={item.name} />
            <h2>{item.name}</h2>
            <p>₹{item.price} per kg</p>
            <button className="button" onClick={() => addToCart(item)}>
              ADD TO CART
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductList;
