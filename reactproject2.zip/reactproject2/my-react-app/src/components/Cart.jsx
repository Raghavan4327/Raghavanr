import react from "react";

function  cart({cart, removeFromCart}) {
    return (
        <div>
            <h2 className="title3">CART</h2>
            {cart.length === 0 ?(
                <p className="title3">No Item In Cart</p>
            ):(
                <ol className="flex">
                    {cart.map((item, index)=>(
                        <li key={index}>
                             <img src={item.image} alt={item.name}  /><br></br>
                            {item.name}-{item.price}
                        <button onClick={()=>removeFromCart(index)} className="button3">Remove</button>
                    </li>
                    ))}
                </ol>
            )}
        </div>
    );
    
}

export default cart;