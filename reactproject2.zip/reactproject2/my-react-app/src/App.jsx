import React, { useState } from "react";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout";


function App(){

  const[cart ,setCart]=useState([]);
  const[page ,setPage]=useState("prodcuts");

  const addToCart = (prodcut) =>{
    setCart([...cart, prodcut]);  
  };

  const removeFromCart = (index)=>{
    const newCart=[...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };


  return (

    <div  className="background" style={{ padding: "20px" }}>
      <h1 className="title1"> Vegetables </h1>
      <nav className="buttonv">
        <button onClick={() => setPage("products")}>Products</button>
        <button onClick={() => setPage("cart")}>Cart ({cart.length})</button>
        <button onClick={() => setPage("checkout")}>Checkout</button>
      </nav>
      <hr />

      {page === "products" && <ProductList addToCart={addToCart} />}
      {page === "cart" && <Cart cart={cart} removeFromCart={removeFromCart} />}
      {page === "checkout" && <Checkout cart={cart} />}
    </div>
  );
}

export default App;
